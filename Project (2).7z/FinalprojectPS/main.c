#include <stdio.h>
#include<string.h>
#include<stdbool.h>
#include<stdlib.h>
typedef struct{
int reg_no;
char name[500];
float gpa1;
float gpa2;
float gpa;
float grades[14];
int password;
}student;
typedef struct{
int id;
int password;
char name[150];
int indexsub[7];
}staff;
struct studentss{char reg_no[20];
    char name[500];
    float gpa1;
    float gpa2;
    float gpa;
    float grades[14];
    char password[20];
    int degree[14][4];
};
typedef struct{
char name[500];
char code[7];
int credit;
}Subject;
char c='%';
// Define a struct to write the ID and passwords for registration staff
struct stuff {
char id[20];
char pass[20];
};
typedef struct{
char code[7];
int num;
int index;
}RegCode;

// Define a struct to hold the name,ID,address,grade and section for students
struct student_reg {
    char name[50];
    char id[20];
    char address[100];
    float grade;
    char section[10];
};

// Define a struct to hold the ID and password for staff
struct reg{
    char id[20];
    char password[20];
};

// Define a void func to view register students
    void printTextFile(char *newcomers) {
    FILE *file;
    char buffer[200];
    size_t bytes_read;

    // Open the file in text read mode
    file = fopen(newcomers, "r");

    // Check if the file was opened successfully
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    // Read and print each line of the file
    while (fgets(buffer, 200, file) != NULL) {
        printf("%s", buffer);
    }

    // Close the file
    fclose(file);
};
float convertToDigitGrade(int grade) {
    float points;

    if (grade >= 96 && grade <= 100) {
        points = 4;
    } else if (grade >= 92 && grade < 96) {
        points = 3.7;
    } else if (grade >= 88 && grade < 92) {
        points = 3.4;
    } else if (grade >= 84 && grade < 88) {
        points = 3.2;
    } else if (grade >= 80 && grade < 84) {
        points = 3;
    } else if (grade >= 76 && grade < 80) {
        points = 2.8;
    } else if (grade >= 72 && grade < 76) {
       points = 2.6;
    } else if (grade >= 68 && grade < 72) {
        points = 2.4;
    } else if (grade >= 64 && grade < 68) {
        points = 2.2;
    } else if (grade >= 60 && grade < 64) {
        points = 2;
    } else if (grade >= 55 && grade < 60) {
        points = 1.5;
    } else if (grade >= 50 && grade < 55) {
        points = 1;
    } else if (grade >= 0 && grade < 50) {
        points = 0;
    } else {
        points = -1; // return -1 for invalid input
    }

    return points;
}

/*float GPA(int id) {

    int nostudents = 0, suu = 0, c = 0, indexofstud[7] = { 0 }, ctr = 0, copy;

    FILE* reading;
    reading = fopen("Students.bin", "rb");
    fread(&nostudents, sizeof(int), 1, reading);
    student* pstudents = malloc(sizeof(student) * nostudents);
    fread(pstudents, sizeof(student), nostudents, reading);
    fclose(reading);

    FILE* sub;
    sub = fopen("subjects.bin", "rb");
    fread(&suu, sizeof(int), 1, sub);
    Subject* allsubjects = malloc(sizeof(Subject) * suu);
    fread(allsubjects, sizeof(Subject), suu, sub);
    fclose(sub);

    for (int i = 0; i < nostudents; i++) {
        if (pstudents[i].gpa1 <= 4 && pstudents[i].gpa1 >= 2) {
            c = 7;
            indexofstud[c];
        }
        if (pstudents[i].gpa1 < 2 && pstudents[i].gpa1 >= 0) {
            c = 4;
            indexofstud[c];
        }
        if (id == pstudents[i].reg_no) {
            copy = i;
            for (int j = 0; j < 14; j++) {
                if (ctr == c)
                    break;
                if (pstudents[i].grades[j] == -2) {
                    indexofstud[ctr] = j;
                    ctr++;
                }
            }
        }
        float u, gpa, pointss = 0, creditt = 0;
        for (int i = 0; i < c; i++) {
            printf("Enter the expected grade of %s: ", allsubjects[indexofstud[i]].name);
            scanf("%f", &u);
            creditt += allsubjects[indexofstud[i]].credit;
            pointss += convertToDigitGrade(u);
        }
        gpa = pointss / creditt;
        printf("The GPA of student with ID %d is: %f\n", id, gpa);
    }
    free(pstudents);
    free(allsubjects);
    return 0;
}*/
/*void writingtofile(){

staff s;
strcpy(s.name,"Ali Ahmed Mohamed");
s.indexsub[0]=7;
s.indexsub[1]=8;
s.indexsub[2]=9;
s.indexsub[3]=10;
s.indexsub[4]=11;
s.indexsub[5]=12;
s.indexsub[6]=13;
s.id=123456;
s.password=654122;
    int x=1;
FILE *Staff;
Staff=fopen("Staff.bin","wb");
fwrite(&x,sizeof(int),1,Staff);
fwrite(&s,sizeof(staff),x,Staff);
fclose(Staff);


}*/char* convertingtogrades(int);
void enteringgrades(){
    int indexofstudents[20];
    int ctr=0;
     int studsub;
 FILE *sub,*staf;
 int suu=0,sta=0,nostudents=0;

int k=0;
FILE *reading;
    reading=fopen("Students.bin","rb");
    fread(&nostudents,sizeof(int),1,reading);
    student *pstudents=malloc(sizeof(student)* nostudents);
    fread(pstudents,sizeof(student),nostudents,reading);
    fclose(reading);

  sub=fopen("subjects.bin","rb");
 fread(&suu,sizeof(int),1,sub);
 Subject *allsubjects=malloc(sizeof(Subject)*suu);
 fread(allsubjects,sizeof(Subject),suu,sub);
 fclose(sub);

  staf=fopen("staff.bin","rb");
 fread(&sta,sizeof(int),1,staf);
 staff *allstaff=malloc(sizeof(staff)*sta);
 fread(allstaff,sizeof(staff),sta,staf);
 fclose(staf);




 int l;
 printf("Enter your id: ");
 scanf("%d",&l);
for(int i=0;i<sta;i++){
    if(allstaff[i].id==l){
        for(int j=0;j<7;j++){

            printf("%d  |%-50s |\n",j+1,allsubjects[allstaff[i].indexsub[j]].name);


        }

        printf("Enter the no of the subject you need: ");
        scanf("%d",&studsub);

        for(int k=0;k<20;k++)
        {
            if(pstudents[k].grades[allstaff[i].indexsub[studsub-1]]==-2){
               printf("%-3d |%-40s \n",ctr+1,pstudents[k].name);
               indexofstudents[ctr]=k;
               ctr++;


        }}if(ctr!=0){
        int studententergrad;
            printf("Enter the no of the student you need: ");
            scanf("%d",&studententergrad);
            printf("Name: %s\nRegistration NO: %d",pstudents[indexofstudents[studententergrad-1]].name,pstudents[indexofstudents[studententergrad-1]].reg_no);
            int g1=0,g2=0,g3=0,g4=0;
            printf("\nEnter grades of %s",allsubjects[allstaff[i].indexsub[studsub-1]].name);
            printf("\nfirst grades of 30: ");
            scanf("%d",&g1);
            printf("\nsecond grades of 20: ");
            scanf("%d",&g2);
            printf("\nthird grades of 10: ");
            scanf("%d",&g3);
            printf("\nfourth grades of 40:");
            scanf("%d",&g4);
pstudents[indexofstudents[studententergrad-1]].grades[allstaff[i].indexsub[studsub-1]]=(g1+g2+g3+g4);}
else
    printf("there is no students");



    }

printf("%f",pstudents[4].grades[9]);
FILE *writing;
    writing=fopen("Students.bin","wb");
    fwrite(&nostudents,sizeof(int),1,writing);
    fwrite(pstudents,sizeof(student),nostudents,writing);
    fclose(writing);}


}
void printing_unofficial_transcript(){
    for(int i=0;i<119;i++){
        printf("-");
    }

    printf("\nARAB ACADEMY FOR SCIENCE & TECHNOLOGY & MARITIME TRANSPORT\n");
      for(int i=0;i<119;i++){
        printf("-");
    }
         printf("\n");
    printf("Unofficial transcript\nEnter you Registration NO: ");
       int ero;
    scanf("%d",&ero);
     printf("\n");




    int nostudents=0,numofs=0;

   FILE *reading;
    reading=fopen("Students.bin","rb");
    fread(&nostudents,sizeof(int),1,reading);
    student *pstudents=malloc(sizeof(student)* nostudents);
    fread(pstudents,sizeof(student),nostudents,reading);
    fclose(reading);
    FILE *reading2;
    reading2=fopen("subjects.bin","rb");
    fread(&numofs,sizeof(int),1,reading2);
    Subject *subb=malloc(sizeof(Subject)*numofs);
    fread(subb,sizeof(Subject),numofs,reading2);
    fclose(reading2);
      for(int i=0;i<119;i++){
        printf("-");
    }
         printf("\n");
    for(int i=0;i<(nostudents);i++){
            if(ero==pstudents[i].reg_no){
        printf("Full name: %s\nRegistration NO: %d\nGPA OF Semester one: %.2f\nGPA OF Semester two: %.2f\n",pstudents[i].name,pstudents[i].reg_no,pstudents[i].gpa1,pstudents[i].gpa2);
printf("+----------------------------------------------------+-------+\n");
printf("| Subject                                            | Grade |\n");
printf("+----------------------------------------------------+-------+\n");
for(int x=0; x<14; x++) {
    printf("| %-50s | %-5s |\n", subb[x].name, convertingtogrades(pstudents[i].grades[x]));
}
printf("+----------------------------------------------------+-------+\n");

    }

}
   for(int i=0;i<119;i++){
        printf("-");
    }
         printf("\n");
free(pstudents);
free(subb);
}

void regist() {
    int ofstudents = 0, ofsubjects = 0, ctr = 0, copyofstudentorder = 0, subjectctrreg = 0, input[50], w = 0;
    int x, reg_subj[7];
    printf("Enter the student id: ");
    scanf("%d", &x);

    FILE* filestudent;
    filestudent = fopen("Students.bin", "rb");
    fread(&ofstudents, sizeof(int), 1, filestudent);
    student* allstudents = malloc(sizeof(student) * ofstudents);
    fread(allstudents, sizeof(student), ofstudents, filestudent);
    fclose(filestudent);

    FILE* file_subject;
    file_subject = fopen("subjects.bin", "rb");
    fread(&ofsubjects, sizeof(int), 1, file_subject);
    Subject* allsubjects = malloc(sizeof(Subject) * ofsubjects);
    fread(allsubjects, sizeof(Subject), ofsubjects, file_subject);
    fclose(file_subject);






    for (int i = 0; i < ofstudents; i++) {
        if (allstudents[i].reg_no == x) {
            copyofstudentorder = i;
            int counter = 0;
            for (int j = 0; j < ofsubjects; j++) {
                if (allstudents[i].grades[j] == -1)
                    counter++;
            }
            if (counter == ofsubjects) {
                for (int k = 0; k < 7; k++) {
                    reg_subj[k] = k;
                    ctr = -5;
                }
            }
            else {

                for (int m = 0; m < ofsubjects && ctr < 7; m++) {
                    if (allstudents[i].grades[m] == -1 || allstudents[i].grades[m] == -3 || (allstudents[i].grades[m] >= 0 && allstudents[i].grades[m] < 50)) {
                        if (m == 7 && (allstudents[i].grades[0] >= 50 && allstudents[i].grades[0] <= 100)) {
                            reg_subj[ctr] = 7;
                            ctr++;
                        }
                        else if (m == 8 && (allstudents[i].grades[1] >= 50 && allstudents[i].grades[1] <= 100)) {
                            reg_subj[ctr] = 8;
                            ctr++;
                        }
                        else if (m == 10 && (allstudents[i].grades[3] >= 50 && allstudents[i].grades[3] <= 100)) {
                            reg_subj[ctr] = 10;
                            ctr++;
                        }
                        else if (m == 11 && (allstudents[i].grades[4] >= 50 && allstudents[i].grades[4] <= 100)) {
                            reg_subj[ctr] = 11;
                            ctr++;
                        }
                        else if (m == 13 && (allstudents[i].grades[4] >= 50 && allstudents[i].grades[4] <= 100)) {
                            reg_subj[ctr] = 13;
                            ctr++;
                        }
                        else if (m != 7 && m != 8 && m != 10 && m != 11 && m != 13) {
                            reg_subj[ctr] = m;
                            ctr++;
                        }
                    }
                }


            }
        }
    }
    if (allstudents[copyofstudentorder].gpa1 < 2 && ctr != -5)
        ctr = 4;
    else if (ctr == -5)
        ctr = 7;
    int noorg;
    RegCode* RegCoSub = malloc(sizeof(RegCode) * ctr);
    printf("Registration Part\nStudent Name: %s\nStudent Registration NO: %d\n", allstudents[copyofstudentorder].name, allstudents[copyofstudentorder].reg_no);

    printf("+--+-----------------------------------------+--------------+------------------+\n");
    printf("|%2s | %-38s | %-12s | %-16s |\n", "NO", "Subject Name", "Subject Code", "Subject Credit");
    printf("+--+-----------------------------------------+--------------+------------------+\n");
    for (int p = 0; p < ctr; p++) {
        strcpy(RegCoSub[p].code, allsubjects[reg_subj[p]].code);
        RegCoSub[p].num = p + 1;
        RegCoSub[p].index = reg_subj[p];
        printf("|%2d | %-38s | %-12s | %-16d |\n", RegCoSub[p].num, allsubjects[reg_subj[p]].name, allsubjects[reg_subj[p]].code, allsubjects[reg_subj[p]].credit);

    }
    printf("+--+-----------------------------------------+--------------+------------------+\n");

label1:
    printf("Enter the Subject's NO: ");
    scanf("%d", &noorg);
    input[w] = noorg;
    for (int c = 0; c < w; c++) {
        if (noorg == input[c]) {
            printf("Already enrolled\n");
            goto label1;
        }
    }
    switch (noorg) {
    case 1:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    case 2:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    case 3:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    case 4:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    case 5:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    case 6:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    case 7:
        allstudents[copyofstudentorder].grades[RegCoSub[noorg - 1].index] = -2;
        subjectctrreg++;
        printf("You are enrolled successfully\n");
        break;
    default:
        printf("You are not allowed to enroll this Subject\n");
    }
    w++;
    if (subjectctrreg != ctr)
        goto label1;

    FILE* editedstudents;
    editedstudents = fopen("Students.bin", "wb");
    fwrite(&ofstudents, sizeof(int), 1, editedstudents);
    fwrite(allstudents, sizeof(student), ofstudents, editedstudents);
    fclose(editedstudents);
    free(allstudents);
}

int main()
{strt:
              printf("                             _    _      _                            \n");
  printf("                            | |  | |    | |                          \n");
  printf("                            | |  | | ___| | ___ ___  _ __ ___   ___  \n");
  printf("                            | |/\\| |/ _ \\ |/ __/ _ \\| '_ ` _ \\ / _ \\\n");
  printf("                            \\  /\\  /  __/ | (_| (_) | | | | | |  __/ \n");
  printf("                             \\/  \\/ \\___|_|\\___\\___/|_| |_| |_|\\___| \n");
  printf("\n");
  printf("                                          AAST SYSTEM\n");
    printf("\n\nIf you Registration staff press [1] ,doctors and TAs press [2] ,student press [3]: ");
    int visitor;
    scanf("%d",&visitor);
    getchar();
    switch(visitor)
{
    case 1:  //staff
    {
    struct reg staff[4];
    FILE *fr;
    char search_id[20];
    char search_pass[20];
    char search_name[20];

    //struct stuff write[4];*/  //code for write reg staff data
   /* for(int i=0;i<4;i++){
    printf("Enter your id: ");
    fgets(write[i].id,11,stdin);
    printf("Enter your password: ");
    fgets(write[i].pass,11,stdin);
 }

    fr=fopen("regstaffdata.bin","wb");
    fwrite(write, sizeof(struct stuff), 4, fr);
    fclose(fr);
    */


    // Open the binary file in read-only mode
    fr = fopen("regstaffdata.bin", "rb");
    fread(staff, sizeof(struct reg), 4, fr);
    fclose(fr); // Close the file
    for(int j=1;j<=2;j++)
    {
   // make the user to enter the ID and password to search for to access
    printf("\nEnter your ID: ");
    fgets(search_id,20,stdin);
    printf("\nEnter your pass: ");
    fgets(search_pass,20,stdin);

    int found = 0; // Flag variable to track successful login

    for(int i=0; i<4; i++)
    {
    if(strcmp(staff[i].id, search_id) == 0 && strcmp(staff[i].password, search_pass) == 0)
    {
        system("cls"); // Clear the screen
        printf("\nYou are successfully logged in!\n");
        found = 1; // Set flag to indicate successful login

        printf("\nChoose:\n1-View new comers students registered for 2023/2024.\n2-Add a student for 2023/2024 registration.\n3-Delete student registered for 2023/2024.\n4-Modify Student registered for 2023/2024.\n");
        int ch;
        scanf("%d",&ch);
        getchar(); // To consume the newline character left by scanf
        switch(ch)
            {
            case 1://view new comers file
                {
                    printTextFile("newcomers.txt");
                    break;
                }
            case 2://add new student for 2023/2024
                {
                    printf("Register new student to college of computing & information technology: ");
                    printf("\n\nStudent specialty:\n1-Scientfic or \t2-literary\n");
                    int spec;
                    scanf("%d",&spec);
                    getchar();

                    switch(spec)
                    {
                    case 1://right section
                    {
                        float sanwiagrade;
                        printf("\nEnter Sanawia amma grade: ");
                        scanf("%f",&sanwiagrade);
                        getchar();
                        switch(sanwiagrade<65)
                        {
                            case 0: //grade and section is right
                    {
                    system("cls"); // Clear the screen
                    struct student_reg s;
                    FILE *fp;

            // Get input from user
            printf("Enter name: ");
            fgets(s.name, 50, stdin);

            printf("Enter ID: ");
            fgets(s.id, 20, stdin);

            printf("Enter address: ");
            fgets(s.address, 100, stdin);

            printf("Enter grade: ");
            scanf("%f", &s.grade);

            getchar(); // To consume the newline character left by scanf

            printf("Enter Section(Science or mathematics): ");
            fgets(s.section, 10, stdin);

            // Open file for writing
            fp = fopen("newcomers.txt", "a");

            if (fp == NULL) {
            printf("Error opening file");
            exit(1);
            }

           // Write to file
           fprintf(fp, "Name: %sID: %sAddress: %sGrade of Sanawia Ama: %.2f%c\nSection(Science or mathematics): %s\n\n", s.name, s.id, s.address, s.grade,c, s.section);

          // Close file
          fclose(fp);
                    break;
                    } // case 0: //grade and section is right

                    case 1://grade is under the minimum
                    {
                        printf("This student is not applicable to this major the minimum grade is 65%");
                        break;
                    }
                    default:
                        {
                            printf("Invalid input.");
                            break;
                        }
                    } //end of switch sanwiagrade
                     break;
                    } //case 1://right section
                    case 2://wrong section
                    {
                        printf("This student is not applicable to this major");
                        break;
                    }
                    default:
                    {
                    printf("Invalid input");
                    break;
                    }
                    } //end of spec switch
                    break;
                }
            case 3://delete student for 2023/2024
                {
                    FILE *fd, *temp;
                   char buffer[1024];
                   char *data_to_delete[200];
                   // The data to delete
                   printf("Enter the label of deleted student:");
                   fgets(data_to_delete,200,stdin);
                   int line_number = 1; // The current line number

                    // Open the original file in read mode
                    fd = fopen("newcomers.txt", "r");

                    if (fd == NULL) {
                    printf("Error opening file.\n");
                    return 1;
                    }

                    // Open the temporary file in write mode
                    temp = fopen("temp.txt", "w");

    if (temp == NULL) {
        printf("Error creating temporary file.\n");
        fclose(fd);
        return 1;
    }

    // Read the original file line by line, copying all lines except the one that contains the data to delete to the temporary file
    while (fgets(buffer, 1024, fd) != NULL) {
        if (strstr(buffer, data_to_delete) != NULL) {
            // Found the data to delete, so delete the current line and the next 4 lines
            for (int i = 0; i < 5; i++) {
                if (fgets(buffer, 1024, fd) == NULL) {
                    break;
                }
                line_number++;
            }
        } else {
            // Not the line to delete, so copy it to the temporary file
            fputs(buffer, temp);
            line_number++;
        }
    }

    // Close both files
fclose(fd);
    fclose(temp);

    // Delete the original file and rename the temporary file to the original file name
    remove("newcomers.txt");
    rename("temp.txt", "newcomers.txt");
                   break;
                }
            case 4://modify student data for 2023/2024
                {
                    FILE *fe, *temp;
                    char buffer[1024];
                    char data_to_edit[200];
                    char new_edited[200];
                    // The data to edit
                    printf("Enter the data you want to modify: ");
                    fgets(data_to_edit, 200, stdin);
                    printf("Enter the category of new data then the new data to modify: ");
                    fgets(new_edited, 200, stdin);

                    // Open the original file in read mode
                    fe = fopen("newcomers.txt", "r");

                    if (fe == NULL) {
                        printf("Error opening file.\n");
                        return 1;
                    }

                    // Open the temporary file in write mode
                    temp = fopen("temp.txt", "w");

                    if (temp == NULL) {
                        printf("Error creating temporary file.\n");
                        fclose(fe);
                        return 1;
                    }

                    // Read the original file line by line, copying all lines to the temporaryfile with the edited data
                    while (fgets(buffer, 1024, fe) != NULL)
                    {
                        // Trim any trailing whitespace characters from the data to edit
                        char *pos;
                        if ((pos = strchr(data_to_edit, '\n')) != NULL) {
                            *pos = '\0';
                        }

                        if (strstr(buffer, data_to_edit) != NULL)
                        {
                            // Found the data to edit, so replace it with the new data
                            strcpy(buffer, new_edited);
                        }
                        // Copy the line to the temporary file with the edited data
                        fputs(buffer, temp);
                    }

                    // Close both files
                    fclose(fe);
                    fclose(temp);

                    // Delete the original file and rename the temporary file to the original file name
                    remove("newcomers.txt");
                    rename("temp.txt", "newcomers.txt");
                    break;
                }
            default:
                {
                    printf("Invalid input");
                }


            }//end of switch cases users chooses

        }//end of if condition
fclose(fr);
if(!found)// If the loop completes without finding a match, print an error message
    {
    system("cls"); // Clear the screen
    printf("\nInvalid id or password, Please Enter Your id and Your Password Correctly\n");
    }
    break;
    }// end of for loop for i
    int cont;
printf("\nback to main menu press [1] , close the program press [0]: ");
if(scanf("%d",&cont)){

    switch (cont){
case 1:
    getchar();
    j--;
    continue;
default:
    return 0;
    }
}



}//end of loop for j
    }

   case 2:  // Dr and TAs
    {
    up:
        printf("For registering subjects, press [1].\nFor entering grades, press [2].\n");
        int swa;
        scanf("%d", &swa);
        if (swa == 1) {
            regist();
        } else if (swa == 2) {
            enteringgrades();
        } else {
            system("cls");
            printf("Invalid input. Please enter a choice again.\n");
            goto up;
        }
    }
    break;



    case 3:  //student
    {up2:
    printf("For Unofficial transcript press[1],For gpa calulator for current semester[2] ");
    int lal;
    scanf("%d",&lal);
    if(lal==1){
    printing_unofficial_transcript();

    }
    else if(lal==2){
    int id;
    printf("Enter the student ID: ");
    scanf("%d", &id);
    struct studentss r1;
    int arr[7], sum, total;
    float final_result = 0;
            for (int i = 0; i < 7; i++) {
                sum = 0;
                switch (i) {
                    case 0:
                        printf("Please enter your Calculus grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                    case 1:
                        printf("Please enter your Advanced physics grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                    case 2:
                        printf("Please enter your Academic writing grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                    case 3:
                        printf("Please enter your Discrete structure grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                    case 4:
                        printf("Please enter your Entrepreneurship grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                    case 5:
                        printf("Please enter your Problem solving grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                    case 6:
                        printf("Please enter your Communication skills grades in the following order:\n\"7th degree\", \"12th degree\", \"Course work\", and \"Final degree\".\n");
                        break;
                }

                for (int j = 0; j < 4; j++) {
                    in:
                    if (scanf("%d", &r1.degree[i][j]) != 1) {
                        printf("Invalid input. Please enter a digit.\n");
                        fflush(stdin);
                        goto in;
                    }

                    if (r1.degree[i][j] < 0 || r1.degree[i][j] > 100) {
                        printf("Invalid input. Please enter a grade between 0 and 100.\n");
                        j--; // repeat the loop if the input is invalid
                        continue;
                    }

                    sum += r1.degree[i][j];
                }
                fflush(stdin);
                float points = convertToDigitGrade(sum);
                if (points == -1) {
                    printf("Invalid input. Please enter grades between 0 and 100.\n");
                    i--; // repeat the loop if the input is invalid
                    continue;
                }

                switch (i) {
                    case 0: // Calculus
                    case 1: // Advanced physics
                    case 3: // Discrete structure
                    case 5: // Problem solving
                        total = points * 3;
                        break;
                    case 2: // Academic writing
                    case 4: // Entrepreneurship
                    case 6: // Communication skills
                        total = points * 2;
                        break;
                }

                final_result += total;
            }

            for (int i = 0; i < 7; i++) {
                switch (i) {
                    case 0:
                        printf("\nCalculus:\n");
                        break;
                    case 1:
                        printf("\nAdvanced physics:\n");
                        break;
                    case 2:
                        printf("\nAcademic writing:\n");
                        break;
                    case 3:
                        printf("\nDiscrete structure:\n");
                        break;
                    case 4:
                        printf("\nEntrepreneurship:\n");
                        break;
                    case 5:
                        printf("\nProblem solving:\n");
                        break;
                    case 6:
                        printf("\nCommunication skills:\n");
                        break;
                }

                for (int j = 0; j < 4; j++) {
                    printf("%d ", r1.degree[i][j]);
                }
            }
            printf("\nThe GPA = %.1f\n", final_result / 18);
return 0;
    }
    else{
        system("cls");
            printf("Invalid input. Please enter a choice again.\n");
            goto up2;
    }

        break;
    }



    default:
    {system("cls");
        printf("Invalid input,please enter your choice again");
        goto strt;
        break;
    }

} //end of loop visitor

 return 0;
}
char* convertingtogrades(x){
char* g=malloc(sizeof(char)*3);
 if(x<=100&&x>=96)
strcpy(g, "A");
else if(x>=92&&x<96)
strcpy(g, "A");
else if(x>=88&&x<92)
strcpy(g, "A-");
else if(x>=84&&x<88)
strcpy(g, "B+");
else if(x>=80&&x<84)
strcpy(g, "B");
else if(x>=76&&x<80)
strcpy(g, "B-");
else if(x>=72&&x<76)
    strcpy(g, "C+");
else if(x>=68&&x<72)
strcpy(g, "C");
else if (x>=64&&x<68)
strcpy(g, "C-");
else if(x>=60&&x<64)
    strcpy(g, "D+");
else if(x>=55&&x<60)
strcpy(g, "D");
else if(x>=50&&x<55)
strcpy(g, "D-");
else if(x>=0&&x<50)
strcpy(g, "F");
else if(x==-3)
  strcpy(g, "W");
else if(x==-1)
strcpy(g, "-");
else if(x==-2)
strcpy(g, "-");
else
    return;

return g;
    }
